#include<stdio.h>
void main(){
    int i=32;
    while(i<=63){
        printf("%c %4d   0x%04x",i,i,i);
        if((i+32)<=95){
            printf("%4c %4d   0x%04x",i+32,i+32,i+32);
            if((i+64<=126))
            printf("%4c %4d   0x%04x\n",i+64,i+64,i+64); 
            else
                printf("\n");             
        }
        i++;
    }

}