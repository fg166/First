#include<stdio.h>
    int main()
    {
        int a=1;
        printf("hello world\n");
        printf("hello debug\n");
        a++;
        printf("hello 1\n");
        printf("hello 2\n");
        return 0;
    }