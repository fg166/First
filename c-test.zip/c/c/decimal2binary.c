#include<stdio.h>

void main( )
{
    int n;
    scanf("%d",&n);
    int result=0,k=1,i,temp;
    temp = n;
    while(temp){
    i = temp%2;
    result += k * i;
    k = k*10;
    temp = temp/2;
    }
    printf("二进制表示为：%d\n", result);
    
}